Voici un script Python utilisant le module `http.server` pour créer un serveur web qui démontrera comment créer et lire un cookie lors de requêtes GET.

### Script Python pour Créer et Lire un Cookie en GET

```python
import http.server
from http.cookies import SimpleCookie

class SimpleHTTPRequestHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        # Parse cookies
        cookie = SimpleCookie(self.headers.get('Cookie'))

        # Check if 'username' cookie is set
        if 'username' in cookie:
            username = cookie['username'].value
            message = f"Welcome back, {username}!"
        else:
            # If 'username' cookie is not set, set it with a default value
            username = "Guest"
            cookie = SimpleCookie()
            cookie['username'] = username
            cookie['username']['path'] = '/'
            cookie['username']['max-age'] = 3600  # Cookie expires in 1 hour
            self.send_header("Set-Cookie", cookie.output(header='', sep=''))

            message = "Hello, Guest! Cookie has been set."

        # Construct the response
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(f"<html><body><h1>{message}</h1></body></html>".encode('utf-8'))

def run(server_class=http.server.HTTPServer, handler_class=SimpleHTTPRequestHandler):
    server_address = ('', 8000)
    httpd = server_class(server_address, handler_class)
    print("Serving on port 8000...")
    httpd.serve_forever()

if __name__ == '__main__':
    run()
```

### Explications

1. **Initialisation du Serveur** :
   - Le script utilise `http.server.HTTPServer` pour créer un serveur HTTP simple.
   - Le serveur écoute sur le port 8000.

2. **Gestion des Requêtes GET** :
   - Le serveur vérifie si un cookie nommé `username` existe.
   - Si le cookie existe, il lit la valeur et affiche un message de bienvenue personnalisé.
   - Si le cookie n'existe pas, il définit un cookie `username` avec la valeur "Guest" et une durée de vie de 1 heure, puis affiche un message indiquant que le cookie a été défini.

3. **Définition et Lecture des Cookies** :
   - Le cookie est défini en utilisant l'en-tête `Set-Cookie`.
   - Les cookies sont lus à partir de l'en-tête `Cookie` des requêtes HTTP.

### Instructions pour Exécuter le Script

1. **Exécutez le script Python** :

   ```bash
   python3 script_name.py
   ```

2. **Accédez au serveur** :

   Ouvrez votre navigateur web et accédez à `http://localhost:8000`.

3. **Tester le Fonctionnement des Cookies** :

   - La première visite définira un cookie avec la valeur "Guest".
   - Rafraîchissez la page pour voir le message de bienvenue personnalisé.

Avec ce script, vous pouvez observer comment les cookies sont créés et lus à chaque requête GET.