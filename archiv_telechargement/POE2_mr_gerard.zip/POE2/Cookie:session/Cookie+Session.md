### Script Python pour la Gestion de Session avec Cookies

Ce script démontrera comment créer et gérer des sessions en utilisant des cookies pour stocker l'identifiant de session. Les informations de session seront stockées en mémoire sur le serveur.

```python
import http.server
import random
import string
from http.cookies import SimpleCookie

# Stocker les sessions en mémoire
sessions = {}

def generate_session_id():
    """Génère un identifiant de session unique."""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=16))

class SessionHTTPRequestHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        # Parse cookies
        cookie = SimpleCookie(self.headers.get('Cookie'))
        session_id = None

        # Check if 'session_id' cookie is set
        if 'session_id' in cookie:
            session_id = cookie['session_id'].value

            # Check if session_id exists in the sessions dictionary
            if session_id in sessions:
                user_data = sessions[session_id]
                message = f"Welcome back, {user_data['username']}!"
            else:
                message = "Session not found. Please log in."
                session_id = None
        else:
            message = "No session found. Please log in."

        # If no valid session, create a new one
        if not session_id:
            session_id = generate_session_id()
            sessions[session_id] = {'username': 'Guest'}
            cookie = SimpleCookie()
            cookie['session_id'] = session_id
            cookie['session_id']['path'] = '/'
            cookie['session_id']['max-age'] = 3600  # Cookie expires in 1 hour
            self.send_header("Set-Cookie", cookie.output(header='', sep=''))

        # Construct the response
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(f"""
            <html>
            <body>
                <h1>{message}</h1>
                <form method="POST" action="/">
                    <label for="username">Enter your username:</label>
                    <input type="text" id="username" name="username">
                    <input type="submit" value="Submit">
                </form>
            </body>
            </html>
        """.encode('utf-8'))

    def do_POST(self):
        # Parse form data
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        parsed_data = urllib.parse.parse_qs(post_data.decode('utf-8'))

        # Get the username from the form data
        username = parsed_data.get('username', ['Guest'])[0]

        # Parse cookies
        cookie = SimpleCookie(self.headers.get('Cookie'))
        session_id = None

        # Check if 'session_id' cookie is set
        if 'session_id' in cookie:
            session_id = cookie['session_id'].value

            # Check if session_id exists in the sessions dictionary
            if session_id in sessions:
                # Update session data
                sessions[session_id]['username'] = username
            else:
                session_id = None

        # If no valid session, create a new one
        if not session_id:
            session_id = generate_session_id()
            sessions[session_id] = {'username': username}
            cookie = SimpleCookie()
            cookie['session_id'] = session_id
            cookie['session_id']['path'] = '/'
            cookie['session_id']['max-age'] = 3600  # Cookie expires in 1 hour
            self.send_header("Set-Cookie", cookie.output(header='', sep=''))

        # Redirect to the root path
        self.send_response(303)
        self.send_header("Location", "/")
        self.end_headers()

def run(server_class=http.server.HTTPServer, handler_class=SessionHTTPRequestHandler):
    server_address = ('', 8000)
    httpd = server_class(server_address, handler_class)
    print("Serving on port 8000...")
    httpd.serve_forever()

if __name__ == '__main__':
    run()
```

### Explications

1. **Initialisation du Serveur** :
   - Le script utilise `http.server.HTTPServer` pour créer un serveur HTTP simple.
   - Le serveur écoute sur le port 8000.

2. **Gestion des Sessions** :
   - Les sessions sont stockées dans un dictionnaire `sessions`, où les clés sont des identifiants de session uniques et les valeurs sont des dictionnaires contenant les données de session (par exemple, le nom d'utilisateur).
   - La fonction `generate_session_id` génère un identifiant de session unique de 16 caractères.

3. **Gestion des Requêtes GET** :
   - Le serveur vérifie si un cookie `session_id` existe.
   - Si le cookie `session_id` existe et correspond à une session valide, il lit les données de session et affiche un message de bienvenue personnalisé.
   - Si le cookie `session_id` n'existe pas ou n'est pas valide, il crée une nouvelle session avec un identifiant de session unique et définit un cookie `session_id` avec une durée de vie de 1 heure.

4. **Gestion des Requêtes POST** :
   - Le serveur lit les données du formulaire envoyées via une requête POST pour obtenir le nom d'utilisateur.
   - Il vérifie si un cookie `session_id` existe.
   - Si le cookie `session_id` existe et correspond à une session valide, il met à jour les données de session avec le nouveau nom d'utilisateur.
   - Si le cookie `session_id` n'existe pas ou n'est pas valide, il crée une nouvelle session avec le nom d'utilisateur soumis et définit un cookie `session_id` avec une durée de vie de 1 heure.
   - Le serveur redirige ensuite l'utilisateur vers la page d'accueil.

### Instructions pour Exécuter le Script

1. **Exécutez le script Python** :

   ```bash
   python3 script_name.py
   ```

2. **Accédez au serveur** :

   Ouvrez votre navigateur web et accédez à `http://localhost:8000`.

3. **Tester la Gestion des Sessions** :

   - La première visite créera une nouvelle session et définira un cookie `session_id`.
   - Soumettez le formulaire avec un nom d'utilisateur pour mettre à jour les données de session.
   - Rafraîchissez la page pour voir le message de bienvenue personnalisé basé sur le cookie de session.

Ce script démontre comment gérer les sessions en utilisant des cookies pour stocker des identifiants de session dans une application web simple.