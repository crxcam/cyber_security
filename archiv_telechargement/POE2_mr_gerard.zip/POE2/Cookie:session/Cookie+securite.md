La sécurisation des cookies est essentielle pour protéger les données sensibles et assurer la confidentialité et l'intégrité des sessions utilisateur. Voici quelques pratiques recommandées pour sécuriser les cookies :

### Pratiques de Sécurisation des Cookies

1. **Utilisation du drapeau `HttpOnly`** :
   - Empêche l'accès aux cookies par les scripts côté client (JavaScript), réduisant ainsi le risque d'attaques XSS (Cross-Site Scripting).
   - **Exemple** :
     ```python
     cookie['session_id']['httponly'] = True
     ```

2. **Utilisation du drapeau `Secure`** :
   - Assure que le cookie est transmis uniquement via des connexions HTTPS sécurisées.
   - **Exemple** :
     ```python
     cookie['session_id']['secure'] = True
     ```

3. **Utilisation du drapeau `SameSite`** :
   - Limite les cookies aux requêtes provenant du même site, aidant à prévenir les attaques CSRF (Cross-Site Request Forgery).
   - **Valeurs possibles** :
     - `Lax` : Les cookies sont envoyés avec les requêtes de navigation GET initiées par des sites tiers (le comportement par défaut).
     - `Strict` : Les cookies ne sont envoyés qu'avec les requêtes initiées par le site web qui a créé le cookie.
     - `None` : Les cookies sont envoyés avec les requêtes initiées par des sites tiers (nécessite également le drapeau `Secure`).
   - **Exemple** :
     ```python
     cookie['session_id']['samesite'] = 'Lax'
     ```

4. **Définir des dates d'expiration appropriées** :
   - Limitez la durée de vie des cookies pour réduire le risque d'accès prolongé.
   - **Exemple** :
     ```python
     cookie['session_id']['max-age'] = 3600  # Expire après 1 heure
     ```

5. **Stockage sécurisé des données de session** :
   - Évitez de stocker des informations sensibles directement dans les cookies. Stockez plutôt un identifiant de session et conservez les données sensibles sur le serveur.
   - **Exemple** :
     ```python
     cookie['session_id'] = generate_session_id()
     ```

6. **Chiffrement des données de cookie** :
   - Si vous devez stocker des informations sensibles dans les cookies, chiffrez ces données avant de les stocker.
   - Utilisez des bibliothèques de chiffrement fiables comme `cryptography` en Python.

### Exemple Complet en Python

Voici un script Python utilisant le module `http.server` et `http.cookies` pour démontrer la sécurisation des cookies avec les pratiques mentionnées ci-dessus :

```python
import http.server
import random
import string
from http.cookies import SimpleCookie

# Générer un identifiant de session unique
def generate_session_id():
    return ''.join(random.choices(string.ascii_letters + string.digits, k=16))

# Stocker les sessions en mémoire (pour la démonstration)
sessions = {}

class SecureSessionHTTPRequestHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        # Parse cookies
        cookie = SimpleCookie(self.headers.get('Cookie'))
        session_id = None

        # Check if 'session_id' cookie is set
        if 'session_id' in cookie:
            session_id = cookie['session_id'].value
            # Check if session_id exists in the sessions dictionary
            if session_id in sessions:
                user_data = sessions[session_id]
                message = f"Welcome back, {user_data['username']}!"
            else:
                message = "Session not found. Please log in."
                session_id = None
        else:
            message = "No session found. Please log in."

        # If no valid session, create a new one
        if not session_id:
            session_id = generate_session_id()
            sessions[session_id] = {'username': 'Guest'}
            cookie = SimpleCookie()
            cookie['session_id'] = session_id
            cookie['session_id']['path'] = '/'
            cookie['session_id']['max-age'] = 3600  # Cookie expires in 1 hour
            cookie['session_id']['httponly'] = True
            cookie['session_id']['secure'] = True
            cookie['session_id']['samesite'] = 'Lax'
            self.send_header("Set-Cookie", cookie.output(header='', sep=''))

        # Construct the response
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(f"""
            <html>
            <body>
                <h1>{message}</h1>
                <form method="POST" action="/">
                    <label for="username">Enter your username:</label>
                    <input type="text" id="username" name="username">
                    <input type="submit" value="Submit">
                </form>
            </body>
            </html>
        """.encode('utf-8'))

    def do_POST(self):
        # Parse form data
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length)
        parsed_data = urllib.parse.parse_qs(post_data.decode('utf-8'))

        # Get the username from the form data
        username = parsed_data.get('username', ['Guest'])[0]

        # Parse cookies
        cookie = SimpleCookie(self.headers.get('Cookie'))
        session_id = None

        # Check if 'session_id' cookie is set
        if 'session_id' in cookie:
            session_id = cookie['session_id'].value
            # Check if session_id exists in the sessions dictionary
            if session_id in sessions:
                # Update session data
                sessions[session_id]['username'] = username
            else:
                session_id = None

        # If no valid session, create a new one
        if not session_id:
            session_id = generate_session_id()
            sessions[session_id] = {'username': username}
            cookie = SimpleCookie()
            cookie['session_id'] = session_id
            cookie['session_id']['path'] = '/'
            cookie['session_id']['max-age'] = 3600  # Cookie expires in 1 hour
            cookie['session_id']['httponly'] = True
            cookie['session_id']['secure'] = True
            cookie['session_id']['samesite'] = 'Lax'
            self.send_header("Set-Cookie", cookie.output(header='', sep=''))

        # Redirect to the root path
        self.send_response(303)
        self.send_header("Location", "/")
        self.end_headers()

def run(server_class=http.server.HTTPServer, handler_class=SecureSessionHTTPRequestHandler):
    server_address = ('', 8000)
    httpd = server_class(server_address, handler_class)
    print("Serving on port 8000...")
    httpd.serve_forever()

if __name__ == '__main__':
    run()
```

### Explications des Directives de Sécurité Utilisées

1. **HttpOnly** :
   - Défini pour empêcher l'accès au cookie par les scripts côté client.
   ```python
   cookie['session_id']['httponly'] = True
   ```

2. **Secure** :
   - Défini pour assurer que le cookie est transmis uniquement via HTTPS.
   ```python
   cookie['session_id']['secure'] = True
   ```

3. **SameSite** :
   - Défini pour restreindre l'envoi des cookies avec les requêtes intersites.
   ```python
   cookie['session_id']['samesite'] = 'Lax'
   ```

4. **Expiration** :
   - Définie pour limiter la durée de vie du cookie.
   ```python
   cookie['session_id']['max-age'] = 3600  # Expire après 1 heure
   ```

En suivant ces pratiques de sécurité, vous pouvez sécuriser efficacement les cookies dans vos applications web, réduisant ainsi les risques d'attaques courantes telles que XSS et CSRF.