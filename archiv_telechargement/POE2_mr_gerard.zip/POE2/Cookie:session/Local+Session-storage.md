### LocalStorage et SessionStorage

**LocalStorage** et **SessionStorage** sont deux types de stockage web fournis par les navigateurs modernes via l'API Web Storage. Ils permettent de stocker des paires clé-valeur dans le navigateur, offrant un moyen simple et persistant de stocker des données côté client.

### LocalStorage

**LocalStorage** est une méthode de stockage persistant. Les données stockées dans LocalStorage ne sont pas supprimées lorsque le navigateur est fermé. Elles persistent jusqu'à ce qu'elles soient explicitement supprimées par le code JavaScript ou manuellement par l'utilisateur.

**Caractéristiques de LocalStorage :**
- **Durée de vie** : Persiste jusqu'à ce qu'elles soient supprimées.
- **Portée** : Les données sont accessibles à toutes les pages du même domaine.
- **Capacité** : Généralement 5-10 MB selon le navigateur.

**Exemple d'utilisation :**
```javascript
// Stocker des données
localStorage.setItem('username', 'JohnDoe');

// Récupérer des données
const username = localStorage.getItem('username');

// Supprimer des données
localStorage.removeItem('username');

// Supprimer toutes les données
localStorage.clear();
```

### SessionStorage

**SessionStorage** est une méthode de stockage temporaire. Les données stockées dans SessionStorage sont disponibles pour la durée de la session de navigation. Elles sont supprimées lorsque la page de navigation ou l'onglet est fermé.

**Caractéristiques de SessionStorage :**
- **Durée de vie** : Jusqu'à ce que l'onglet ou la fenêtre de navigation soit fermé.
- **Portée** : Les données sont accessibles uniquement à la page et ses cadres imbriqués dans l'onglet actuel.
- **Capacité** : Généralement 5-10 MB selon le navigateur.

**Exemple d'utilisation :**
```javascript
// Stocker des données
sessionStorage.setItem('username', 'JohnDoe');

// Récupérer des données
const username = sessionStorage.getItem('username');

// Supprimer des données
sessionStorage.removeItem('username');

// Supprimer toutes les données
sessionStorage.clear();
```

### Différences entre LocalStorage et SessionStorage

| Caractéristique      | LocalStorage                                   | SessionStorage                               |
|----------------------|-------------------------------------------------|----------------------------------------------|
| **Durée de vie**     | Persiste indéfiniment jusqu'à suppression explicite | Persistant jusqu'à la fermeture de l'onglet  |
| **Portée**           | Accessible à toutes les pages du même domaine  | Accessible uniquement dans l'onglet actuel   |
| **Capacité**         | Généralement 5-10 MB selon le navigateur       | Généralement 5-10 MB selon le navigateur     |
| **Cas d'utilisation**| Stockage de préférences utilisateur, jetons d'authentification, etc. | Stockage de données de session temporaires comme l'état de la page |

### Cas d'Utilisation

**LocalStorage** est idéal pour :
- Stocker les préférences de l'utilisateur (thème, langue, etc.).
- Stocker des jetons d'authentification pour maintenir les utilisateurs connectés entre les sessions.
- Sauvegarder des données d'application qui doivent persister entre les fermetures du navigateur.

**SessionStorage** est idéal pour :
- Stocker des données de session temporaires comme l'état d'un formulaire ou les éléments d'une session de panier d'achat.
- Stocker des données qui doivent être disponibles uniquement pour la durée de vie de l'onglet ou de la fenêtre de navigation.

### Conclusion

**LocalStorage** et **SessionStorage** sont des outils puissants pour stocker des données côté client. La principale différence réside dans la durée de vie des données stockées. LocalStorage persiste les données même après la fermeture du navigateur, tandis que SessionStorage conserve les données uniquement pour la durée de vie de l'onglet ou de la fenêtre de navigation. Le choix entre les deux dépend des besoins spécifiques de votre application en matière de persistance et de portée des données.