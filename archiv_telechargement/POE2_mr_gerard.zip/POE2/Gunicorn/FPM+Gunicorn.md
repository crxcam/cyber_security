### Interfacer PHP avec un Reverse Proxy

#### Introduction

Un reverse proxy est un serveur qui se situe devant les serveurs web et redirige les requêtes client vers ces derniers. Il est couramment utilisé pour la répartition de charge, la mise en cache, la compression, et la sécurisation des applications web.

#### Solutions pour interfacer PHP avec un reverse proxy

1. **Nginx + PHP-FPM** (FastCGI Process Manager)
   - **Nginx** : Serveur web performant et léger, utilisé comme reverse proxy.
   - **PHP-FPM** : Gère les scripts PHP via le protocole FastCGI, permettant une exécution rapide et efficace.
   - **Configuration** : Nginx est configuré pour rediriger les requêtes PHP vers PHP-FPM.
     ```nginx
     server {
         listen 80;
         server_name example.com;

         location / {
             try_files $uri $uri/ =404;
         }

         location ~ \.php$ {
             include snippets/fastcgi-php.conf;
             fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
         }
     }
     ```

2. **Apache + mod_proxy + PHP Module**
   - **Apache** : Serveur web populaire, utilisé comme reverse proxy et serveur d'application PHP.
   - **mod_proxy** : Module Apache permettant de rediriger les requêtes vers différents backend.
   - **PHP Module** : Intégré dans Apache pour exécuter les scripts PHP.
   - **Configuration** : Apache redirige les requêtes via `mod_proxy` et traite les scripts PHP avec son module PHP.
     ```apache
     <VirtualHost *:80>
         ServerName example.com

         ProxyPass /app http://backend-server/app
         ProxyPassReverse /app http://backend-server/app

         <Directory /var/www/html>
             Options Indexes FollowSymLinks
             AllowOverride None
             Require all granted
         </Directory>

         <FilesMatch \.php$>
             SetHandler "proxy:unix:/var/run/php/php7.4-fpm.sock|fcgi://localhost/"
         </FilesMatch>
     </VirtualHost>
     ```

### Gunicorn en tant que reverse proxy pour les applications Python WSGI

#### Introduction

Gunicorn est un serveur HTTP pour les applications Python WSGI. Bien qu'il ne soit pas un reverse proxy à proprement parler, il joue un rôle crucial dans la gestion des requêtes HTTP pour les applications Python.

#### Rôle de Gunicorn

1. **Serveur WSGI** :
   - **WSGI** : Gunicorn sert les applications web Python conformes à WSGI, facilitant la communication entre les serveurs web (comme Nginx) et les applications Python.
   - **Multiprocessus** : Utilise plusieurs processus pour gérer les requêtes simultanément, améliorant la performance.

2. **Interaction avec Reverse Proxy (comme Nginx)** :
   - **Configuration** : Nginx est couramment utilisé en tant que reverse proxy devant Gunicorn pour gérer les requêtes statiques, la mise en cache, et la sécurisation des connexions. Gunicorn gère les requêtes dynamiques.
     ```nginx
     server {
         listen 80;
         server_name example.com;

         location / {
             proxy_pass http://127.0.0.1:8000;
             proxy_set_header Host $host;
             proxy_set_header X-Real-IP $remote_addr;
             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
             proxy_set_header X-Forwarded-Proto $scheme;
         }
     }
     ```

3. **Flexibilité et Performance** :
   - **Pré-forking** : Crée plusieurs processus de travail dès le démarrage pour gérer efficacement les requêtes entrantes.
   - **Monitoring et Redémarrage** : Surveille les processus et redémarre automatiquement les processus échoués.

#### Configuration de Gunicorn

Pour lancer une application Flask avec Gunicorn, par exemple :
```bash
gunicorn -w 4 -b 127.0.0.1:8000 myapp:app
```
- `-w 4` : Indique d'utiliser 4 workers.
- `-b 127.0.0.1:8000` : Indique d'écouter sur l'adresse locale et le port 8000.

### Conclusion

- **PHP avec Reverse Proxy** : Utilise des serveurs web comme Nginx ou Apache pour rediriger les requêtes et exécuter les scripts PHP via PHP-FPM ou les modules PHP.
- **Gunicorn pour Python** : Sert les applications web Python en tant que serveur WSGI performant et est souvent utilisé avec des reverse proxies comme Nginx pour une gestion optimale des requêtes.