### Utilisation de Gunicorn avec Apache

Gunicorn peut également être utilisé avec Apache en tant que reverse proxy pour servir des applications Python WSGI. Apache, avec ses modules `mod_proxy` et `mod_proxy_http`, peut rediriger les requêtes vers Gunicorn, qui exécute l'application Python.

#### Installation de Gunicorn

Pour installer Gunicorn, utilisez `pip` :
```bash
pip install gunicorn
```

#### Exemple d'application Python

Supposons que vous avez une application Flask située dans un fichier `app.py` :

```python
from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello():
    return "Hello, World!"

if __name__ == "__main__":
    app.run()
```

#### Démarrage de l'application avec Gunicorn

Pour démarrer cette application avec Gunicorn, utilisez la commande suivante :
```bash
gunicorn -w 4 -b 127.0.0.1:8000 app:app
```
- `-w 4` : Spécifie le nombre de workers (processus de travail). Ici, 4 workers seront utilisés.
- `-b 127.0.0.1:8000` : Spécifie l'adresse IP et le port sur lesquels Gunicorn doit écouter.

#### Configuration d'Apache

1. **Installer les modules nécessaires** :
   - Assurez-vous que les modules `proxy`, `proxy_http` et `proxy_fcgi` sont activés dans Apache. Vous pouvez les activer avec les commandes suivantes :
     ```bash
     sudo a2enmod proxy
     sudo a2enmod proxy_http
     sudo a2enmod proxy_fcgi
     ```

2. **Configuration Apache** :
   - Modifier le fichier de configuration Apache (par exemple, `/etc/apache2/sites-available/000-default.conf`) pour rediriger les requêtes vers Gunicorn :
     ```apache
     <VirtualHost *:80>
         ServerName example.com

         # Redirection des requêtes vers Gunicorn
         ProxyPass / http://127.0.0.1:8000/
         ProxyPassReverse / http://127.0.0.1:8000/

         # Paramètres pour les en-têtes
         <Proxy *>
             Order deny,allow
             Allow from all
         </Proxy>

         ProxyPreserveHost On

         # Logs
         ErrorLog ${APACHE_LOG_DIR}/error.log
         CustomLog ${APACHE_LOG_DIR}/access.log combined
     </VirtualHost>
     ```

3. **Redémarrer Apache** :
   - Après avoir modifié la configuration, redémarrez Apache pour appliquer les modifications :
     ```bash
     sudo systemctl restart apache2
     ```

#### Utilisation de `mod_proxy_uwsgi` (Optionnel)

Si vous préférez utiliser le module `mod_proxy_uwsgi` pour une communication plus efficace, vous pouvez le faire en suivant ces étapes :

1. **Activer le module `mod_proxy_uwsgi`** :
   - Activez le module avec la commande suivante :
     ```bash
     sudo a2enmod proxy_uwsgi
     ```

2. **Configuration Apache** :
   - Modifier le fichier de configuration Apache pour rediriger les requêtes vers Gunicorn via le protocole uWSGI :
     ```apache
     <VirtualHost *:80>
         ServerName example.com

         # Redirection des requêtes vers Gunicorn via uWSGI
         ProxyPass / uwsgi://127.0.0.1:8000/
         ProxyPassReverse / uwsgi://127.0.0.1:8000/

         # Paramètres pour les en-têtes
         <Proxy *>
             Order deny,allow
             Allow from all
         </Proxy>

         ProxyPreserveHost On

         # Logs
         ErrorLog ${APACHE_LOG_DIR}/error.log
         CustomLog ${APACHE_LOG_DIR}/access.log combined
     </VirtualHost>
     ```

#### Gestion des Workers

1. **Types de Workers** :
   - **Sync Workers** : Idéaux pour les applications web typiques, chaque worker traite une requête à la fois.
   - **Async Workers** : Utilisés pour les applications nécessitant une grande concurrence, comme les applications WebSocket ou les API à haute performance. Exemples : `gevent`, `eventlet`.
     ```bash
     gunicorn -k gevent -w 4 -b 127.0.0.1:8000 app:app
     ```

2. **Redémarrage Automatique** :
   - Gunicorn peut redémarrer les workers s'ils échouent, assurant ainsi la résilience.
   - Utilisez le signal `HUP` pour redémarrer Gunicorn avec les nouvelles configurations :
     ```bash
     kill -HUP <gunicorn_master_pid>
     ```

#### Surveillance et Journalisation

Gunicorn fournit des options pour la surveillance et la journalisation des applications en production.

1. **Logs** :
   - Spécifier les fichiers de log pour les erreurs et les accès :
     ```bash
     gunicorn --access-logfile access.log --error-logfile error.log app:app
     ```

2. **Outils de Surveillance** :
   - Utiliser des outils comme `supervisor` ou `systemd` pour gérer et surveiller les processus Gunicorn.

### Conclusion

Gunicorn est un outil puissant et flexible pour déployer des applications web Python en production. En combinaison avec Apache, il offre une solution robuste pour gérer les requêtes HTTP et exécuter les applications Python. Voici un résumé de son utilisation :

- **Installation** : Facile avec `pip`.
- **Configuration** : Flexible via la ligne de commande, des fichiers de configuration, ou des variables d'environnement.
- **Déploiement** : Efficace en combinaison avec Apache pour gérer les requêtes statiques et dynamiques.
- **Gestion** : Prend en charge différents types de workers et offre des fonctionnalités de surveillance et de journalisation robustes.

