### Usage de Gunicorn

Gunicorn (Green Unicorn) est un serveur HTTP WSGI pour les applications Python. Il est conçu pour être rapide, léger, et simple à utiliser, idéal pour déployer des applications web Python en production. Voici une description détaillée de son utilisation :

#### Installation

Pour installer Gunicorn, utilisez `pip` :
```bash
pip install gunicorn
```

#### Démarrage d'une Application avec Gunicorn

Supposons que vous avez une application Flask située dans un fichier `app.py` :

```python
from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello():
    return "Hello, World!"

if __name__ == "__main__":
    app.run()
```

Pour démarrer cette application avec Gunicorn, utilisez la commande suivante :
```bash
gunicorn -w 4 -b 127.0.0.1:8000 app:app
```
- `-w 4` : Spécifie le nombre de workers (processus de travail). Ici, 4 workers seront utilisés.
- `-b 127.0.0.1:8000` : Spécifie l'adresse IP et le port sur lesquels Gunicorn doit écouter.

#### Configuration Avancée

Gunicorn peut être configuré à l'aide de la ligne de commande, de variables d'environnement, ou de fichiers de configuration.

1. **Configuration via Ligne de Commande** :
   - Définir le nombre de workers :
     ```bash
     gunicorn --workers 3 app:app
     ```
   - Utiliser un fichier de configuration Gunicorn :
     ```bash
     gunicorn -c gunicorn_config.py app:app
     ```

2. **Fichier de Configuration Gunicorn** (`gunicorn_config.py`) :
   ```python
   bind = "127.0.0.1:8000"
   workers = 4
   timeout = 30
   ```

3. **Variables d'Environnement** :
   - Définir les variables d'environnement pour la configuration :
     ```bash
     export GUNICORN_CMD_ARGS="--workers=4 --bind=127.0.0.1:8000"
     gunicorn app:app
     ```

#### Utilisation avec Nginx

Pour utiliser Gunicorn derrière un reverse proxy comme Nginx, voici comment configurer Nginx pour rediriger les requêtes vers Gunicorn.

1. **Configuration Nginx** :
   - Modifier le fichier de configuration Nginx (par exemple, `/etc/nginx/sites-available/default`) :
     ```nginx
     server {
         listen 80;
         server_name example.com;

         location / {
             proxy_pass http://127.0.0.1:8000;
             proxy_set_header Host $host;
             proxy_set_header X-Real-IP $remote_addr;
             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
             proxy_set_header X-Forwarded-Proto $scheme;
         }
     }
     ```

2. **Redémarrer Nginx** :
   - Redémarrer Nginx pour appliquer les modifications :
     ```bash
     sudo systemctl restart nginx
     ```

#### Gestion des Workers

1. **Types de Workers** :
   - **Sync Workers** : Idéaux pour les applications web typiques, chaque worker traite une requête à la fois.
   - **Async Workers** : Utilisés pour les applications nécessitant une grande concurrence, comme les applications WebSocket ou les API à haute performance. Exemples : `gevent`, `eventlet`.
     ```bash
     gunicorn -k gevent -w 4 -b 127.0.0.1:8000 app:app
     ```

2. **Redémarrage Automatique** :
   - Gunicorn peut redémarrer les workers s'ils échouent, assurant ainsi la résilience.
   - Utilisez le signal `HUP` pour redémarrer Gunicorn avec les nouvelles configurations :
     ```bash
     kill -HUP <gunicorn_master_pid>
     ```

#### Surveillance et Journalisation

Gunicorn fournit des options pour la surveillance et la journalisation des applications en production.

1. **Logs** :
   - Spécifier les fichiers de log pour les erreurs et les accès :
     ```bash
     gunicorn --access-logfile access.log --error-logfile error.log app:app
     ```

2. **Outils de Surveillance** :
   - Utiliser des outils comme `supervisor` ou `systemd` pour gérer et surveiller les processus Gunicorn.

### Conclusion

Gunicorn est un outil puissant et flexible pour déployer des applications web Python en production. Il offre une configuration simple, une haute performance grâce à son modèle multiprocessus, et une intégration facile avec des reverse proxies comme Nginx. Voici un résumé de son utilisation :

- **Installation** : Facile avec `pip`.
- **Configuration** : Flexible via la ligne de commande, des fichiers de configuration, ou des variables d'environnement.
- **Déploiement** : Efficace en combinaison avec Nginx pour gérer les requêtes statiques et dynamiques.
- **Gestion** : Prend en charge différents types de workers et offre des fonctionnalités de surveillance et de journalisation robustes.

