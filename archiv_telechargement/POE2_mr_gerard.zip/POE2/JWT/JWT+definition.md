### Définition de JWT

**JWT** (JSON Web Token) est un standard ouvert (RFC 7519) pour la création de jetons d'accès utilisés pour l'authentification et l'échange sécurisé d'informations entre parties. Un JWT est un jeton compact, auto-contenu, et sécurisé qui peut être vérifié et validé numériquement.

### Structure de JWT

Un JWT est composé de trois parties séparées par des points (`.`) :

1. **Header (En-tête)** :
   - **Alg** : L'algorithme de signature (par exemple, HMAC SHA256 ou RSA).
   - **Typ** : Le type de jeton (typique `JWT`).

   ```json
   {
     "alg": "HS256",
     "typ": "JWT"
   }
   ```

2. **Payload (Charge utile)** :
   - Contient les informations ou les réclamations (claims). Les claims sont des déclarations sur une entité (généralement, l'utilisateur) et des métadonnées supplémentaires.

   ```json
   {
     "sub": "1234567890",
     "name": "John Doe",
     "iat": 1516239022
   }
   ```

3. **Signature (Signature)** :
   - Crée en prenant l'en-tête codé en base64, le payload codé en base64, un secret, et l'algorithme spécifié dans l'en-tête.

   ```plaintext
   HMACSHA256(
     base64UrlEncode(header) + "." +
     base64UrlEncode(payload),
     secret)
   ```

### Exemple de JWT

Un JWT typique ressemble à ceci :

```plaintext
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c
```

### Site pour analyser simplement un JWT

**[JWT.io](https://jwt.io/)** est un site web interactif qui fournit des outils et des ressources pour travailler avec les JSON Web Tokens (JWT). Le site est développé et maintenu par Auth0, une société spécialisée dans la gestion des identités et des accès.

### Fonctionnalités de JWT.io

1. **Décodeur de JWT** :
   - Permet de décoder, vérifier et générer des JWT directement depuis le navigateur.
   - Affiche l'en-tête, le payload et la signature d'un JWT, ainsi que leur contenu décodé en JSON.

2. **Vérification de JWT** :
   - Permet de vérifier la validité des JWT en fournissant une clé secrète ou publique.
   - Indique si la signature est valide et si le JWT a expiré.

3. **Générateur de JWT** :
   - Facilite la création de nouveaux JWT en fournissant des champs pour l'en-tête, le payload, et la signature.
   - Supporte différents algorithmes de signature, comme HS256, RS256, et ES256.

4. **Bibliothèques et Documentation** :
   - Fournit des liens vers des bibliothèques JWT pour différents langages de programmation, telles que Python, JavaScript, Java, PHP, Ruby, et Go.
   - Offre une documentation complète sur le format JWT et son utilisation.

### Usage de JWT

1. **Authentification** :
   - Les JWT sont souvent utilisés pour authentifier les utilisateurs. Lorsqu'un utilisateur se connecte, le serveur crée un JWT et le renvoie au client. Le client stocke ce JWT (généralement dans le stockage local ou un cookie sécurisé) et l'envoie dans les en-têtes des requêtes futures. Le serveur peut ensuite vérifier ce JWT pour authentifier les requêtes.
   - **Exemple** :
     - L'utilisateur se connecte avec ses identifiants.
     - Le serveur génère un JWT et l'envoie au client.
     - Le client inclut le JWT dans les en-têtes de requêtes pour accéder aux ressources protégées.

2. **Autorisation** :
   - Les JWT contiennent des informations sur les autorisations et les rôles de l'utilisateur. Le serveur peut vérifier ces informations pour autoriser ou refuser l'accès à certaines ressources.

3. **Échange sécurisé d'informations** :
   - Les JWT peuvent être utilisés pour échanger des informations sécurisées entre parties. Par exemple, un serveur peut envoyer un JWT contenant des informations chiffrées à un autre serveur.

### Fonctionnement de JWT

1. **Création du JWT** :
   - Le serveur crée un JWT contenant l'en-tête, le payload et la signature. La signature est créée en utilisant un secret ou une clé privée.
   - **Exemple de création en Python** :
     ```python
     import jwt
     import datetime

     secret = "your-256-bit-secret"
     payload = {
       "sub": "1234567890",
       "name": "John Doe",
       "iat": datetime.datetime.utcnow()
     }

     token = jwt.encode(payload, secret, algorithm="HS256")
     print(token)
     ```

2. **Stockage du JWT** :
   - Le client reçoit le JWT et le stocke. Typiquement, les clients stockent les JWT dans le stockage local (`localStorage`) ou dans des cookies sécurisés.

3. **Envoi du JWT** :
   - Pour chaque requête, le client inclut le JWT dans l'en-tête `Authorization` :
     ```plaintext
     Authorization: Bearer <token>
     ```

4. **Vérification du JWT** :
   - Le serveur reçoit le JWT et vérifie sa signature pour s'assurer qu'il n'a pas été altéré.
   - **Exemple de vérification en Python** :
     ```python
     decoded = jwt.decode(token, secret, algorithms=["HS256"])
     print(decoded)
     ```

### Sécurisation des JWT

1. **Utilisation de HTTPS** :
   - Toujours utiliser HTTPS pour sécuriser la transmission des JWT. Cela empêche les attaques de type "man-in-the-middle".

2. **Utilisation de la revendication `exp` (Expiration)** :
   - Définir une expiration pour les JWT pour limiter leur durée de vie et réduire le risque d'utilisation abusive.
   ```json
   {
     "exp": 1516239022
   }
   ```

3. **Révocation des JWT** :
   - Les JWT sont stateless, donc révoquer un JWT peut être difficile. Utilisez une liste de révocation ou une rotation fréquente des clés de signature pour invalider les JWT compromis.

4. **Utilisation de `HttpOnly` et `Secure` pour les cookies** :
   - Si vous stockez des JWT dans des cookies, utilisez les drapeaux `HttpOnly` et `Secure` pour réduire les risques de vol de cookie via XSS.

### Conclusion

Les JWT sont un moyen puissant et flexible pour l'authentification et l'échange sécurisé d'informations. En suivant les meilleures pratiques de sécurisation et en comprenant leur fonctionnement, vous pouvez tirer parti de leurs avantages tout en minimisant les risques potentiels.