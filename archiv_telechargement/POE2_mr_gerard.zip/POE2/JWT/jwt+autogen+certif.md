Il est tout à fait possible de générer des clés RSA directement dans le script Python sans passer par des commandes shell.

La bibliothèque `cryptography` permet de le faire facilement.

Ce script génère une paire de clés RSA, les utilise pour signer et vérifier un JWT, et gère l'écriture et la lecture des clés depuis des fichiers.

### Script complet avec génération de clés RSA

```python
import jwt
import datetime
import os
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend

# Variables
private_key_file = 'private.pem'
public_key_file = 'public.pem'
jwt_file = 'jwt_token.txt'
algorithm = 'RS256'

# Générer les clés RSA
def generate_rsa_keys():
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    public_key = private_key.public_key()

    # Sauvegarder la clé privée
    with open(private_key_file, 'wb') as file:
        file.write(private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption()
        ))

    # Sauvegarder la clé publique
    with open(public_key_file, 'wb') as file:
        file.write(public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ))

# Charger les clés RSA depuis les fichiers
def load_rsa_keys():
    with open(private_key_file, 'rb') as file:
        private_key = serialization.load_pem_private_key(
            file.read(),
            password=None,
            backend=default_backend()
        )

    with open(public_key_file, 'rb') as file:
        public_key = serialization.load_pem_public_key(
            file.read(),
            backend=default_backend()
        )

    return private_key, public_key

def create_jwt(private_key):
    payload = {
        'user_id': 123,
        'exp': datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=1)
    }
    token = jwt.encode(payload, private_key, algorithm=algorithm)
    return token

def save_jwt_to_file(token):
    with open(jwt_file, 'w') as file:
        file.write(token)

def read_jwt_from_file():
    with open(jwt_file, 'r') as file:
        token = file.read()
    return token

def decode_jwt(token, public_key):
    try:
        decoded_payload = jwt.decode(token, public_key, algorithms=[algorithm])
        return decoded_payload
    except jwt.ExpiredSignatureError:
        return "Token has expired"
    except jwt.InvalidTokenError:
        return "Invalid token"

# Script principal
if __name__ == "__main__":
    # Générer les clés si elles n'existent pas
    if not os.path.exists(private_key_file) or not os.path.exists(public_key_file):
        print("Generating RSA keys...")
        generate_rsa_keys()

    # Charger les clés RSA
    private_key, public_key = load_rsa_keys()

    if os.path.exists(jwt_file):
        print("JWT file found, reading token...")
        token = read_jwt_from_file()
        decoded_payload = decode_jwt(token, public_key)
        print("Decoded JWT:", decoded_payload)
    else:
        print("JWT file not found, creating new token...")
        token = create_jwt(private_key)
        save_jwt_to_file(token)
        print("New JWT created and saved to file:", token)
```

### Explications des changements

1. **Génération des clés RSA** :

   - `generate_rsa_keys` : Cette fonction génère une paire de clés RSA et les enregistre dans des fichiers `private.pem` et `public.pem`.

2. **Chargement des clés RSA** :

   - `load_rsa_keys` : Cette fonction lit les clés RSA à partir des fichiers `private.pem` et `public.pem`.

3. **Utilisation des clés** :

   - Les clés générées sont utilisées pour signer (avec la clé privée) et vérifier (avec la clé publique) le JWT.

4. **Gestion des fichiers JWT et des clés** :
   - Le script vérifie si les clés existent déjà ; sinon, il les génère.
   - Le script vérifie si un fichier JWT existe ; sinon, il en crée un nouveau.

Ce script assure que tout est géré en interne sans nécessiter de commandes shell externes.
