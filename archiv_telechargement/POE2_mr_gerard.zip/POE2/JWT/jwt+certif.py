# À faire avant de lancer ce script :
# # Générer une clé privée RSA
# openssl genpkey -algorithm RSA -out private.pem -pkeyopt rsa_keygen_bits:2048
# # Extraire la clé publique de la clé privée
# openssl rsa -pubout -in private.pem -out public.pem

import jwt
import datetime
import os

# Variables
private_key_file = "private.pem"
public_key_file = "public.pem"
jwt_file = "jwt_token+certif.txt"
algorithm = "RS256"

# Lire les clés RSA depuis les fichiers
with open(private_key_file, "r") as file:
    private_key = file.read()

with open(public_key_file, "r") as file:
    public_key = file.read()


def create_jwt():
    payload = {
        "user_id": 123,
        "exp": datetime.datetime.now(datetime.timezone.utc)
        + datetime.timedelta(hours=1),
    }
    token = jwt.encode(payload, private_key, algorithm=algorithm)
    return token


def save_jwt_to_file(token):
    with open(jwt_file, "w") as file:
        file.write(token)


def read_jwt_from_file():
    with open(jwt_file, "r") as file:
        token = file.read()
    return token


def decode_jwt(token):
    try:
        decoded_payload = jwt.decode(token, public_key, algorithms=[algorithm])
        return decoded_payload
    except jwt.ExpiredSignatureError:
        return "Token has expired"
    except jwt.InvalidTokenError:
        return "Invalid token"


# Script principal
if __name__ == "__main__":
    if os.path.exists(jwt_file):
        print("JWT file found, reading token...")
        token = read_jwt_from_file()
        decoded_payload = decode_jwt(token)
        print("Decoded JWT:", decoded_payload)
    else:
        print("JWT file not found, creating new token...")
        token = create_jwt()
        save_jwt_to_file(token)
        print("New JWT created and saved to file:", token)
