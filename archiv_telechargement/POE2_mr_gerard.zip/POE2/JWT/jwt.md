

Voici un script Python utilisant PyJWT qui vérifie l'existence d'un fichier contenant un JWT.  
S'il ne trouve pas le fichier, il crée un nouveau JWT et l'enregistre dans un fichier.  
Lors des lancements suivants, il lit le JWT depuis le fichier et le décode pour afficher les informations contenues.

```python
# pip install pyjwt
import jwt
import datetime
import os

# Variables
secret_key = 'your_secret_key'
jwt_file = 'jwt_token.txt'
algorithm = 'HS256'

def create_jwt():
    payload = {
        'user_id': 123,
        'exp': datetime.datetime.now(datetime.UTC) + datetime.timedelta(hours=1)
    }
    token = jwt.encode(payload, secret_key, algorithm=algorithm)
    return token

def save_jwt_to_file(token):
    with open(jwt_file, 'w') as file:
        file.write(token)

def read_jwt_from_file():
    with open(jwt_file, 'r') as file:
        token = file.read()
    return token

def decode_jwt(token):
    try:
        decoded_payload = jwt.decode(token, secret_key, algorithms=[algorithm])
        return decoded_payload
    except jwt.ExpiredSignatureError:
        return "Token has expired"
    except jwt.InvalidTokenError:
        return "Invalid token"

# Script principal
if __name__ == "__main__":
    if os.path.exists(jwt_file):
        print("JWT file found, reading token...")
        token = read_jwt_from_file()
        decoded_payload = decode_jwt(token)
        print("Decoded JWT:", decoded_payload)
    else:
        print("JWT file not found, creating new token...")
        token = create_jwt()
        save_jwt_to_file(token)
        print("New JWT created and saved to file:", token)
```

### Explication du script

1. **Variables** :

   - `secret_key` : clé secrète utilisée pour signer le JWT.
   - `jwt_file` : nom du fichier où le JWT sera sauvegardé.
   - `algorithm` : algorithme utilisé pour signer le JWT.

2. **Fonction `create_jwt`** :

   - Crée un nouveau JWT avec une charge utile (`payload`) contenant un `user_id` et une date d'expiration (`exp`).

3. **Fonction `save_jwt_to_file`** :

   - Sauvegarde le JWT dans un fichier.

4. **Fonction `read_jwt_from_file`** :

   - Lit le JWT depuis le fichier.

5. **Fonction `decode_jwt`** :

   - Décode le JWT et vérifie sa validité. En cas d'erreur (expiration ou invalidité), un message approprié est retourné.

6. **Script principal** :
   - Vérifie si le fichier contenant le JWT existe. Si oui, lit et décode le JWT. Sinon, crée un nouveau JWT, le sauvegarde dans un fichier et l'affiche.

Tester ce script, consiste à le lancer deux fois.

La première fois, il créera un nouveau JWT et le sauvegardera dans le fichier.  
La deuxième fois, il lira le JWT depuis le fichier et affichera son contenu décodé.
