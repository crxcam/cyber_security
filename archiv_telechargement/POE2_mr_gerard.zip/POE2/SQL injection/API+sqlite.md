Nous utiliserons Flask pour créer l'API web et sqlite3 pour gérer la base de données.

Voici un script de base pour cela :

1. Installer les dépendances nécessaires :
   ```bash
   pip install Flask sqlite3
   ```

2. Créer le script Python pour l'API web vulnérable :

```python
from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)
DATABASE = 'vulnerable.db'


def init_db():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()


@app.route('/vulnerable', methods=['GET'])
def vulnerable():
    username = request.args.get('username')
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    # Cette requête est vulnérable aux injections SQL
    query = f"SELECT * FROM users WHERE username = '{username}'"
    cursor.execute(query)
    result = cursor.fetchall()

    conn.close()
    return jsonify(result)


@app.route('/add_user', methods=['POST'])
def add_user():
    username = request.form['username']
    password = request.form['password']
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
    conn.commit()
    conn.close()
    return "User added!", 200


if __name__ == '__main__':
    init_db()
    app.run(debug=True)
```

### Explications :

1. **Installation des dépendances** : Nous avons besoin de Flask pour créer l'API web et de sqlite3 pour gérer la base de données SQLite.

2. **Initialisation de la base de données** : La fonction `init_db` crée une table `users` si elle n'existe pas déjà.

3. **Route vulnérable** : La route `/vulnerable` prend un paramètre `username` de la requête et l'utilise directement dans une requête SQL sans aucune protection contre les injections SQL. C'est ce qui rend cette route vulnérable et ce que sqlmap peut exploiter.

4. **Ajout d'utilisateurs** : La route `/add_user` permet d'ajouter de nouveaux utilisateurs à la base de données via une requête POST.

### Utilisation de sqlmap

Pour tester la vulnérabilité avec sqlmap, tu peux utiliser une commande comme celle-ci :

```bash
sqlmap -u "http://127.0.0.1:5000/vulnerable?username=test"
```

Cela permettra à sqlmap de tester l'API pour des vulnérabilités SQL Injection.

### Lancer le script

1. Sauvegarde le script dans un fichier, par exemple `app.py`.
2. Exécute le script avec la commande :
   ```bash
   python app.py
   ```
3. L'API sera disponible à l'adresse `http://127.0.0.1:5000`.

N'hésite pas à me dire si tu as besoin de plus de détails ou d'ajustements.