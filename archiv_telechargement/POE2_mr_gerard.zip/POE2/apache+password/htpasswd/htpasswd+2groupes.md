Pour configurer Apache comme reverse proxy avec des autorisations spécifiques pour les utilisateurs, vous pouvez utiliser les directives d'authentification et d'autorisation d'Apache en conjonction avec les modules `mod_proxy` et `mod_authz_core`.

Voici un exemple de configuration où deux utilisateurs (`user1` et `user2`) ont accès à différents répertoires. `user1` a accès aux deux répertoires, tandis que `user2` a accès à un seul répertoire.

### Étapes de l'Exercice

1. **Installer Apache (si nécessaire)**
2. **Activer les modules Apache nécessaires**
3. **Configurer les utilisateurs et les groupes**
4. **Configurer le site Apache pour agir comme reverse proxy avec autorisation**
5. **Redémarrer Apache**
6. **Vérifier la configuration**

### Détails de l'Exercice

#### Étape 1 : Installer Apache

Si Apache n'est pas déjà installé, installez-le avec la commande suivante :

```bash
sudo apt-get update
sudo apt-get install apache2
```

#### Étape 2 : Activer les modules Apache nécessaires

Activez les modules `proxy`, `proxy_http`, `auth_basic`, et `authz_user` nécessaires pour la configuration du reverse proxy et l'authentification :

```bash
sudo a2enmod proxy
sudo a2enmod proxy_http
sudo a2enmod auth_basic
sudo a2enmod authz_user
```

#### Étape 3 : Configurer les utilisateurs et les groupes

Créez un fichier de mots de passe pour stocker les utilisateurs et leurs mots de passe :

```bash
sudo htpasswd -c /etc/apache2/.htpasswd user1
sudo htpasswd /etc/apache2/.htpasswd user2
```

Vous serez invité à entrer un mot de passe pour chaque utilisateur.

#### Étape 4 : Configurer le site Apache pour agir comme reverse proxy avec autorisation

Créez un fichier de configuration pour le site dans `/etc/apache2/sites-available/`. Par exemple, créez un fichier `reverse-proxy-auth.conf` :

```bash
sudo nano /etc/apache2/sites-available/reverse-proxy-auth.conf
```

Ajoutez la configuration suivante au fichier :

```plaintext
<VirtualHost *:80>
    ServerName www.yourdomain.com

    ProxyPreserveHost On
    ProxyRequests Off
    ServerAdmin webmaster@yourdomain.com

    <Proxy *>
        Require all granted
    </Proxy>

    # Répertoire 1
    <Location /dir1>
        AuthType Basic
        AuthName "Restricted Area"
        AuthUserFile /etc/apache2/.htpasswd
        Require user user1 user2

        ProxyPass http://127.0.0.1:3000/dir1
        ProxyPassReverse http://127.0.0.1:3000/dir1
    </Location>

    # Répertoire 2
    <Location /dir2>
        AuthType Basic
        AuthName "Restricted Area"
        AuthUserFile /etc/apache2/.htpasswd
        Require user user1

        ProxyPass http://127.0.0.1:3000/dir2
        ProxyPassReverse http://127.0.0.1:3000/dir2
    </Location>

    ErrorLog ${APACHE_LOG_DIR}/error.log
    CustomLog ${APACHE_LOG_DIR}/access.log combined
</VirtualHost>
```

Ici, nous définissons deux répertoires `/dir1` et `/dir2` :

- `/dir1` est accessible par `user1` et `user2`.
- `/dir2` est accessible uniquement par `user1`.

#### Étape 5 : Activer le site et redémarrer Apache

Activez le site configuré et redémarrez Apache :

```bash
sudo a2ensite reverse-proxy-auth.conf
sudo systemctl restart apache2
```

#### Étape 6 : Vérifier la configuration

Ouvrez un navigateur web et accédez à `http://www.yourdomain.com/dir1` et `http://www.yourdomain.com/dir2`.

- Essayez de vous connecter avec `user1` et `user2` pour `/dir1` et assurez-vous que les deux utilisateurs peuvent accéder.
- Essayez de vous connecter avec `user1` pour `/dir2` et assurez-vous qu'il peut accéder.
- Essayez de vous connecter avec `user2` pour `/dir2` et assurez-vous qu'il ne peut pas accéder.

### Résumé

Dans cet exercice, vous avez appris à :

1. Installer Apache (si nécessaire).
2. Activer les modules nécessaires pour le reverse proxy et l'authentification.
3. Configurer les utilisateurs et les groupes.
4. Configurer un site Apache pour agir comme reverse proxy avec des autorisations spécifiques pour différents répertoires.
5. Redémarrer Apache pour appliquer les modifications.
6. Vérifier que la configuration fonctionne correctement.

Cet exercice vous permet de comprendre comment utiliser Apache pour contrôler l'accès à différents répertoires en fonction des utilisateurs, en utilisant des mécanismes d'authentification de base et de reverse proxy.