Pour configurer Apache afin de gérer les comptes utilisateurs avec `htpasswd`, tu dois suivre quelques étapes simples. Cela inclut l'installation de `htpasswd` (si ce n'est pas déjà fait), la création d'un fichier de mots de passe, et la configuration d'Apache pour utiliser ce fichier pour l'authentification.

### Étapes pour configurer Apache avec `htpasswd`

#### 1. Installer `htpasswd`

Sur de nombreux systèmes, `htpasswd` fait partie du package `apache2-utils` (ou `httpd-tools` sur les systèmes basés sur Red Hat).

Pour Debian/Ubuntu :
```bash
sudo apt-get install apache2-utils
```

Pour Red Hat/CentOS :
```bash
sudo yum install httpd-tools
```

#### 2. Créer un fichier de mots de passe

Crée un fichier de mots de passe et ajoute des utilisateurs avec `htpasswd`.

```bash
sudo htpasswd -c /etc/apache2/.htpasswd nom_utilisateur
```

- `-c` : Crée le fichier. Utilise cette option uniquement lors de la création initiale du fichier. Pour ajouter des utilisateurs supplémentaires, omets cette option.
- `/etc/apache2/.htpasswd` : Chemin vers le fichier de mots de passe.
- `nom_utilisateur` : Nom d'utilisateur pour lequel tu veux créer un mot de passe.

Il te sera demandé de saisir et de confirmer un mot de passe pour l'utilisateur spécifié.

Pour ajouter d'autres utilisateurs, utilise :
```bash
sudo htpasswd /etc/apache2/.htpasswd autre_utilisateur
```

#### 3. Configurer Apache pour utiliser le fichier de mots de passe

Ajoute ou modifie la configuration de ton site dans le fichier de configuration d'Apache. Cela peut être fait dans le fichier de configuration principal (souvent `httpd.conf` ou `apache2.conf`) ou dans un fichier de configuration spécifique au site (souvent situé dans `/etc/apache2/sites-available/`).

Par exemple, pour protéger un répertoire spécifique (`/var/www/html/protected`), tu peux ajouter cette configuration :

```apache
<Directory "/var/www/html/protected">
    AuthType Basic
    AuthName "Restricted Area"
    AuthUserFile /etc/apache2/.htpasswd
    Require valid-user
</Directory>
```

- `AuthType Basic` : Utilise l'authentification de base HTTP.
- `AuthName "Restricted Area"` : Message affiché dans la boîte de dialogue d'authentification.
- `AuthUserFile /etc/apache2/.htpasswd` : Chemin vers le fichier de mots de passe.
- `Require valid-user` : Permet à tout utilisateur valide de se connecter.

#### 4. Redémarrer Apache

Après avoir modifié la configuration, redémarre Apache pour appliquer les modifications :

Pour Debian/Ubuntu :
```bash
sudo systemctl restart apache2
```

Pour Red Hat/CentOS :
```bash
sudo systemctl restart httpd
```

### Vérification

1. **Accéder au répertoire protégé** :
   - Ouvre un navigateur et accède à l'URL du répertoire protégé (par exemple, `http://your-server/protected`).

2. **Authentification** :
   - Une boîte de dialogue d'authentification devrait apparaître. Saisis le nom d'utilisateur et le mot de passe que tu as configurés avec `htpasswd`.

Si tu as bien suivi ces étapes, tu devrais maintenant avoir un répertoire protégé par mot de passe sur ton serveur Apache, géré avec `htpasswd`.