Voici un guide pour créer une autorité de certification (CA) et émettre des certificats avec un script Python utilisant la bibliothèque `cryptography`. Ce script te guidera à travers les étapes de création de la CA, de génération des certificats, et de signature.

### Pré-requis

Assure-toi d'avoir la bibliothèque `cryptography` installée. Si ce n'est pas le cas, installe-la avec :

```bash
sudo apt install 
pip install cryptography
```

### Script Python pour créer une CA et émettre des certificats

```python
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend
import datetime

# Étape 1 : Créer une clé privée pour la CA
def create_private_key():
    key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    return key

# Étape 2 : Créer un certificat auto-signé pour la CA
def create_ca_certificate(key):
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, u"FR"),
        x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, u"Île-de-France"),
        x509.NameAttribute(NameOID.LOCALITY_NAME, u"Paris"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"MaCA"),
        x509.NameAttribute(NameOID.COMMON_NAME, u"MaCA Root CA"),
    ])
    ca_cert = x509.CertificateBuilder().subject_name(
        subject
    ).issuer_name(
        issuer
    ).public_key(
        key.public_key()
    ).serial_number(
        x509.random_serial_number()
    ).not_valid_before(
        datetime.datetime.utcnow()
    ).not_valid_after(
        # Le certificat est valide pendant 10 ans
        datetime.datetime.utcnow() + datetime.timedelta(days=3650)
    ).add_extension(
        x509.BasicConstraints(ca=True, path_length=None), critical=True,
    ).sign(key, hashes.SHA256(), default_backend())
    return ca_cert

# Étape 3 : Écrire la clé privée et le certificat de la CA dans des fichiers
def write_to_files(key, cert, key_file, cert_file):
    with open(key_file, "wb") as f:
        f.write(key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption()
        ))
    with open(cert_file, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

# Étape 4 : Générer une clé privée et une CSR pour le serveur
def create_server_csr(key, common_name):
    csr = x509.CertificateSigningRequestBuilder().subject_name(x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, u"FR"),
        x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, u"Île-de-France"),
        x509.NameAttribute(NameOID.LOCALITY_NAME, u"Paris"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"MonServeur"),
        x509.NameAttribute(NameOID.COMMON_NAME, common_name),
    ])).sign(key, hashes.SHA256(), default_backend())
    return csr

# Étape 5 : Signer le certificat du serveur avec la CA
def sign_certificate(ca_key, ca_cert, csr):
    cert = x509.CertificateBuilder().subject_name(
        csr.subject
    ).issuer_name(
        ca_cert.subject
    ).public_key(
        csr.public_key()
    ).serial_number(
        x509.random_serial_number()
    ).not_valid_before(
        datetime.datetime.utcnow()
    ).not_valid_after(
        # Le certificat est valide pendant 1 an
        datetime.datetime.utcnow() + datetime.timedelta(days=365)
    ).add_extension(
        x509.BasicConstraints(ca=False, path_length=None), critical=True,
    ).sign(ca_key, hashes.SHA256(), default_backend())
    return cert

# Fonction principale
def main():
    # Créer la CA
    ca_key = create_private_key()
    ca_cert = create_ca_certificate(ca_key)
    write_to_files(ca_key, ca_cert, "ca_key.pem", "ca_cert.pem")
    print("CA créée et sauvegardée.")

    # Créer une clé privée pour le serveur et générer une CSR
    server_key = create_private_key()
    server_csr = create_server_csr(server_key, "poec.lan")
    
    # Signer le certificat du serveur avec la CA
    server_cert = sign_certificate(ca_key, ca_cert, server_csr)
    write_to_files(server_key, server_cert, "server_key.pem", "server_cert.pem")
    print("Certificat du serveur créé et sauvegardé.")

if __name__ == "__main__":
    main()
```

### Explication du script

1. **Créer une clé privée pour la CA** : La fonction `create_private_key` génère une clé RSA de 2048 bits.
2. **Créer un certificat auto-signé pour la CA** : La fonction `create_ca_certificate` génère un certificat auto-signé en utilisant la clé privée de la CA.
3. **Écrire la clé privée et le certificat de la CA dans des fichiers** : La fonction `write_to_files` écrit la clé privée et le certificat dans des fichiers.
4. **Générer une clé privée et une CSR pour le serveur** : La fonction `create_server_csr` génère une clé privée et une CSR pour le serveur `poec.lan`.
5. **Signer le certificat du serveur avec la CA** : La fonction `sign_certificate` signe le certificat du serveur en utilisant la clé privée et le certificat de la CA.

### Utilisation

1. **Exécute le script** : Sauvegarde le script dans un fichier `create_certificates.py` et exécute-le avec la commande :

   ```bash
   python create_certificates.py
   ```

2. **Résultats** : Le script générera les fichiers suivants :
   - `ca_key.pem` : Clé privée de la CA
   - `ca_cert.pem` : Certificat de la CA
   - `server_key.pem` : Clé privée du serveur
   - `server_cert.pem` : Certificat du serveur

Ces fichiers peuvent ensuite être utilisés dans la configuration Apache comme décrit dans ma réponse précédente.