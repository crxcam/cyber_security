### Description du Système de Certificats Utilisé pour le Web

Le système de certificats utilisé pour le web est basé sur l'infrastructure à clés publiques (PKI, Public Key Infrastructure).  

La PKI permet de sécuriser les communications sur Internet en utilisant des certificats numériques.

#### 1. **Certificats numériques**
Un certificat numérique est un document électronique qui utilise une signature numérique pour lier une clé publique à une identité. Les certificats numériques sont délivrés par des autorités de certification (CA, Certificate Authorities).

#### 2. **Autorités de Certification (CA)**
Les CA sont des entités de confiance qui vérifient l'identité des entités (comme des sites web) et délivrent des certificats numériques. Les CA bien connues incluent Let's Encrypt, DigiCert, GlobalSign, et Comodo.

#### 3. **Types de Certificats**
   - **Certificats de Serveur (SSL/TLS)** : Utilisés pour sécuriser les communications entre les navigateurs web et les serveurs. Ils assurent que les données échangées sont chiffrées.
   - **Certificats de Client** : Utilisés pour authentifier les clients auprès des serveurs.
   - **Certificats de Code** : Utilisés pour signer numériquement les logiciels et assurer leur intégrité et authenticité.

#### 4. **Structure d'un Certificat Numérique**
Un certificat numérique contient plusieurs informations clés :
   - **Sujet (Subject)** : L'identité à laquelle le certificat est délivré (par exemple, un nom de domaine comme `example.com`).
   - **Émetteur (Issuer)** : L'autorité de certification qui a délivré le certificat.
   - **Clé publique (Public Key)** : La clé publique associée à l'entité.
   - **Période de validité (Validity Period)** : Les dates de début et de fin de validité du certificat.
   - **Empreinte numérique (Fingerprint)** : Une valeur unique générée à partir du certificat pour vérifier son intégrité.
   - **Extensions** : Informations supplémentaires comme les utilisations autorisées du certificat.

#### 5. **Fonctionnement des Certificats SSL/TLS**
   - **Génération de la paire de clés** : Le serveur génère une paire de clés (privée et publique).
   - **CSR (Certificate Signing Request)** : Le serveur crée une demande de signature de certificat contenant la clé publique et d'autres informations, puis l'envoie à une CA.
   - **Validation** : La CA vérifie l'identité du demandeur. Sous ubuntu, les certificats racine pour firefox se trouvent dans '/usr/share/ca-certificates/mozilla/'
   - **Délivrance du certificat** : La CA signe le certificat avec sa clé privée et renvoie le certificat signé au serveur.
   - **Installation du certificat** : Le serveur installe le certificat signé.
   - **Handshake SSL/TLS** : Lorsqu'un client (navigateur web) se connecte au serveur, ils utilisent le protocole SSL/TLS pour établir une connexion sécurisée :
     - Le client demande une connexion sécurisée.
     - Le serveur envoie son certificat au client.
     - Le client vérifie le certificat en utilisant la clé publique de la CA.
     - Si le certificat est valide, le client génère une clé de session, la chiffre avec la clé publique du serveur et l'envoie au serveur.
     - Le serveur déchiffre la clé de session avec sa clé privée.
     - Les deux parties utilisent la clé de session pour chiffrer les communications.

#### 6. **Chaîne de Certificats**
Les certificats SSL/TLS sont souvent organisés en une chaîne de certificats :
   - **Certificat racine** : Le certificat auto-signé de la CA racine, intégré dans les navigateurs web et les systèmes d'exploitation.
   - **Certificat intermédiaire** : Délivré par la CA racine à une CA intermédiaire, qui délivre à son tour des certificats aux serveurs finaux.
   - **Certificat de serveur** : Délivré au serveur web, utilisé pour établir des connexions sécurisées avec les clients.

### Schéma de Fonctionnement

1. **Demande d'un Certificat** : L'administrateur du site web génère une paire de clés (privée et publique) et crée une CSR.
2. **Validation** : La CA vérifie l'identité de l'administrateur et délivre un certificat signé.
3. **Installation du Certificat** : L'administrateur installe le certificat sur le serveur web.
4. **Connexion Sécurisée** : Lorsqu'un utilisateur accède au site web, le serveur présente le certificat, et le navigateur vérifie sa validité.
5. **Établissement d'une Connexion Sécurisée** : Si le certificat est valide, une connexion chiffrée est établie.

### Conclusion

Le système de certificats pour le web repose sur la confiance dans les autorités de certification, la sécurité des clés privées et la validation rigoureuse des identités. Cela permet d'assurer des communications sécurisées et authentiques entre les utilisateurs et les serveurs web.