Le PAM (Pluggable Authentication Modules) est un cadre flexible et modulaire utilisé par les systèmes Unix et Linux pour gérer l'authentification des utilisateurs. PAM permet aux administrateurs système de choisir comment les utilisateurs s'authentifient pour accéder aux services et applications.

### Concepts de Base du PAM

#### 1. Architecture Modulaire

PAM est conçu pour être modulaire, ce qui signifie que les mécanismes d'authentification peuvent être ajoutés, supprimés ou modifiés sans affecter les applications utilisant PAM. Cela se fait en configurant des modules PAM spécifiques pour chaque service d'authentification.

#### 2. Composants Principaux

- **Modules PAM** : Ce sont des bibliothèques partagées qui implémentent les différentes méthodes d'authentification.
- **Configuration PAM** : Les fichiers de configuration se trouvent généralement dans `/etc/pam.d/` et `/etc/pam.conf`.

#### 3. Types de Modules PAM

Il existe quatre types principaux de modules PAM :

- **auth** : Gère l'authentification des utilisateurs (vérification des identités).
- **account** : Gère l'autorisation des utilisateurs (restrictions d'accès basées sur des critères).
- **password** : Gère les changements de mots de passe.
- **session** : Gère les configurations de session (ce qui se passe lors de la connexion et de la déconnexion).

### Fichiers de Configuration PAM

Les fichiers de configuration PAM spécifient quels modules doivent être utilisés pour quels services. Ces fichiers se trouvent dans `/etc/pam.d/` et ont le même nom que le service associé.

#### Exemple de Configuration PAM pour SSH (`/etc/pam.d/sshd`)

```plaintext
#%PAM-1.0
auth       required     pam_sepermit.so
auth       include      password-auth
account    required     pam_nologin.so
account    include      password-auth
password   include      password-auth
session    required     pam_loginuid.so
session    include      password-auth
```

#### Exemple de Configuration PAM pour la Connexion (`/etc/pam.d/login`)

```plaintext
#%PAM-1.0
auth       required     pam_securetty.so
auth       requisite    pam_nologin.so
auth       include      system-auth
account    required     pam_access.so
account    required     pam_nologin.so
account    include      system-auth
password   include      system-auth
session    required     pam_selinux.so close
session    required     pam_loginuid.so
session    optional     pam_console.so
session    required     pam_selinux.so open
session    include      system-auth
```

### Modules PAM Communs

1. **pam_unix.so** : Module pour authentification locale utilisant `/etc/passwd` et `/etc/shadow`.
2. **pam_tally2.so** : Module pour limiter les tentatives de connexion infructueuses et verrouiller les comptes après un certain nombre de tentatives.
3. **pam_securetty.so** : Module pour restreindre les connexions root aux terminaux sécurisés.
4. **pam_nologin.so** : Module pour empêcher les connexions non-root lorsque le fichier `/etc/nologin` existe.
5. **pam_env.so** : Module pour définir des variables d'environnement.
6. **pam_limits.so** : Module pour appliquer des limites de ressources (comme la mémoire ou le nombre de processus).
7. **pam_succeed_if.so** : Module conditionnel qui réussit ou échoue en fonction de certaines conditions (comme l'UID ou le groupe de l'utilisateur).
8. **pam_google_authenticator.so** : Module pour ajouter l'authentification à deux facteurs avec Google Authenticator.

### Fonctionnement de PAM

Lorsqu'un utilisateur tente de s'authentifier à un service utilisant PAM, le processus suivant se déroule :

1. **Demande d'authentification** : L'application demande l'authentification de l'utilisateur.
2. **Appel PAM** : L'application fait appel à PAM pour gérer l'authentification.
3. **Lecture de la configuration** : PAM lit les fichiers de configuration pertinents pour le service.
4. **Exécution des modules** : PAM exécute les modules spécifiés dans la configuration, dans l'ordre, pour chaque type (auth, account, password, session).
5. **Retour du résultat** : Chaque module renvoie un résultat à PAM (succès, échec, etc.).
6. **Décision finale** : PAM prend une décision basée sur les résultats des modules (par exemple, succès global si tous les modules requis réussissent).
7. **Authentification réussie ou échouée** : PAM retourne le résultat à l'application, qui accorde ou refuse l'accès à l'utilisateur.

### Configuration des Modules PAM

Chaque ligne de configuration dans un fichier PAM suit ce format général :

```plaintext
<type> <control-flag> <module-path> <module-arguments>
```

- **type** : Le type de module (auth, account, password, session).
- **control-flag** : Détermine comment le succès ou l'échec du module affecte le résultat global (required, requisite, sufficient, optional).
- **module-path** : Le chemin vers le module PAM.
- **module-arguments** : Arguments optionnels passés au module.

#### Flags de Contrôle

- **required** : Le module doit réussir pour que le processus global réussisse, mais tous les modules seront exécutés.
- **requisite** : Le module doit réussir pour que le processus global réussisse. Si ce module échoue, l'authentification s'arrête immédiatement.
- **sufficient** : Si ce module réussit et qu'aucun module `required` avant lui n'a échoué, l'authentification globale réussit immédiatement.
- **optional** : Le succès ou l'échec de ce module n'affecte pas l'authentification globale, sauf si aucun autre module `required` ou `requisite` n'est présent.

### Conclusion

PAM est un système puissant et flexible pour gérer l'authentification sur les systèmes Linux. Il permet aux administrateurs de personnaliser les mécanismes d'authentification en utilisant une variété de modules et de configurations. Grâce à PAM, il est possible d'ajouter des méthodes d'authentification supplémentaires comme l'authentification à deux facteurs, de contrôler l'accès aux ressources système, et de gérer les sessions utilisateur de manière sécurisée et modulaire.