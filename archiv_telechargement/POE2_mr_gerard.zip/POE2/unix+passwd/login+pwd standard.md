Le système standard de login et mot de passe sous Linux repose sur plusieurs composants et fichiers clés. Voici une vue d'ensemble de son fonctionnement :

### 1. Fichiers de Configuration et Stockage

#### `/etc/passwd`

- Ce fichier contient les informations de base sur les utilisateurs.
- Chaque ligne représente un utilisateur et contient des champs séparés par des deux-points `:` :
  - `username`: Nom de l'utilisateur.
  - `password`: `x` indique que le mot de passe chiffré est stocké dans `/etc/shadow`.
  - `UID`: Identifiant unique de l'utilisateur.
  - `GID`: Identifiant unique du groupe principal de l'utilisateur.
  - `GECOS`: Informations générales sur l'utilisateur.
  - `home directory`: Répertoire personnel de l'utilisateur.
  - `shell`: Shell par défaut de l'utilisateur.

Exemple d'entrée dans `/etc/passwd` :
```plaintext
john:x:1001:1001:John Doe,,,:/home/john:/bin/bash
```

#### `/etc/shadow`

- Ce fichier contient les mots de passe chiffrés et des informations supplémentaires pour chaque utilisateur.
- Chaque ligne représente un utilisateur et contient des champs séparés par des deux-points `:` :
  - `username`: Nom de l'utilisateur.
  - `password`: Mot de passe chiffré (ou `!` pour indiquer que le compte est désactivé).
  - `last password change`: Date du dernier changement de mot de passe (en jours depuis l'époque Unix).
  - `minimum password age`: Nombre de jours minimum avant qu'un mot de passe puisse être changé.
  - `maximum password age`: Nombre de jours maximum avant qu'un mot de passe doit être changé.
  - `password warning period`: Nombre de jours pendant lesquels l'utilisateur est averti avant l'expiration du mot de passe.
  - `password inactivity period`: Nombre de jours après l'expiration du mot de passe pendant lesquels le compte est encore accessible.
  - `account expiration date`: Date d'expiration du compte (en jours depuis l'époque Unix).
  - `reserved`: Réservé pour un usage futur.

Exemple d'entrée dans `/etc/shadow` :
```plaintext
john:$6$randomsalt$hashedpassword:18374:0:99999:7:::
```

### 2. Processus de Connexion

#### `getty` et `login`

- Le processus `getty` gère les terminaux physiques et virtuels. Il affiche l'invite de connexion et attend que l'utilisateur saisisse son nom d'utilisateur.
- Une fois le nom d'utilisateur saisi, `getty` exécute le programme `login` avec ce nom d'utilisateur.

#### Authentification via `login`

- Le programme `login` demande le mot de passe de l'utilisateur.
- Il lit les fichiers `/etc/passwd` et `/etc/shadow` pour obtenir le mot de passe chiffré correspondant au nom d'utilisateur saisi.
- Le mot de passe saisi est chiffré en utilisant le même sel que le mot de passe stocké dans `/etc/shadow`.
- Le mot de passe chiffré saisi est comparé au mot de passe chiffré stocké.
- Si les mots de passe correspondent, l'utilisateur est authentifié et `login` initialise l'environnement de l'utilisateur (par exemple, en définissant le répertoire personnel et le shell par défaut).

### 3. PAM (Pluggable Authentication Modules)

- Linux utilise PAM pour gérer les mécanismes d'authentification de manière modulaire.
- Les configurations PAM pour différents services sont situées dans `/etc/pam.d/`.
- Par exemple, le fichier `/etc/pam.d/sshd` contient les règles PAM pour les connexions SSH.
- PAM permet de configurer différents modules pour des tâches telles que l'authentification, la gestion des sessions, le contrôle des comptes, etc.

Exemple de configuration PAM pour `sshd` (`/etc/pam.d/sshd`) :
```plaintext
auth       required   pam_unix.so
account    required   pam_unix.so
password   required   pam_unix.so
session    required   pam_unix.so
```

### 4. Gestion des Sessions

- Une fois authentifié, le système initialise une session pour l'utilisateur.
- Les fichiers de configuration de session tels que `/etc/profile`, `~/.bash_profile`, `~/.bashrc`, etc., sont exécutés pour configurer l'environnement utilisateur.

### 5. Sécurité

- Les mots de passe sont chiffrés pour empêcher l'accès en clair.
- L'accès au fichier `/etc/shadow` est restreint aux utilisateurs privilégiés (typiquement, seul `root` peut le lire).
- PAM permet une gestion flexible et sécurisée de l'authentification, avec la possibilité d'ajouter des méthodes d'authentification supplémentaires telles que MFA (Multi-Factor Authentication).

En résumé, le système de login et mot de passe Linux repose sur les fichiers `/etc/passwd` et `/etc/shadow` pour stocker les informations des utilisateurs et leurs mots de passe chiffrés. Le processus `login` et PAM gèrent l'authentification et l'initialisation des sessions utilisateur de manière sécurisée.