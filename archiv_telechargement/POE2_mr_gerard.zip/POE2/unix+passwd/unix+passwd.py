import crypt
import os

# Création du fichier contenant les informations d'identification
def create_credentials_file():
    # Mots de passe en clair
    passwords = {
        'user1': 'password1',
        'user2': 'password2'
    }
    
    credentials_content = ""
    for user, pwd in passwords.items():
        hashed_password = hash_password(pwd)
        credentials_content += f"{user}:{hashed_password}\n"
    
    with open('credentials.txt', 'w') as f:
        f.write(credentials_content)

# Génération des mots de passe hachés
def hash_password(password):
    # Générer un sel unique pour chaque mot de passe en utilisant SHA-512
    salt = crypt.mksalt(crypt.METHOD_SHA512)
    return crypt.crypt(password, salt)

# Vérification des informations d'identification
def check_credentials(username, password):
    try:
        with open('credentials.txt', 'r') as f:
            lines = f.readlines()
        
        hashed_password = None
        for line in lines:
            user, stored_hash = line.strip().split(':')
            if user == username:
                hashed_password = stored_hash
                break
        
        if not hashed_password:
            return {'status': 'failure', 'reason': 'Utilisateur non trouvé'}
        
        # Vérifier le mot de passe
        if crypt.crypt(password, hashed_password) == hashed_password:
            return {'status': 'success', 'username': username}
        else:
            return {'status': 'failure', 'reason': 'Mot de passe incorrect'}
    except KeyError:
        return {'status': 'failure', 'reason': 'Utilisateur non trouvé'}

# Création du fichier au démarrage du script
create_credentials_file()

# Exemple d'utilisation
if __name__ == "__main__":
    username = input("Nom d'utilisateur: ")
    password = input("Mot de passe: ")
    
    result = check_credentials(username, password)
    if result['status'] == 'success':
        print(f"Authentification réussie pour l'utilisateur {result['username']}.")
    else:
        print(f"Authentification échouée: {result['reason']}")
